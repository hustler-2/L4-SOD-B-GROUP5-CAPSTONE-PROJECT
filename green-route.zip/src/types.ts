export interface Route {
  id: string;
  name: string;
  origin: string;
  destination: string;
  price: number;
}

export interface Bus {
  id: string;
  routeId: string;
  licensePlate: string;
  capacity: number;
  currentLat: number;
  currentLng: number;
  lastUpdated: any;
  status: 'active' | 'maintenance' | 'completed';
}

export interface Booking {
  id: string;
  busId: string;
  userId: string;
  seats: number[];
  totalPrice: number;
  status: 'pending' | 'confirmed' | 'cancelled';
  timestamp: any;
}
