import React, { useEffect, useState } from 'react';
import { collection, onSnapshot, query, where } from 'firebase/firestore';
import { db } from '../firebase';
import { handleFirestoreError, OperationType } from '../firestoreUtils';
import { Bus, Route } from '../types';
import { RWANDA_BOUNDS } from '../constants';
import { BusFront, Clock, Info, MapPin, Navigation } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

// Help map GPS coordinates to SVG pixels (800x654 coordinate system)
function project(lat: number, lng: number) {
  const width = 800;
  const height = 654;
  
  // Normalized positioning within Rwanda's bounds
  const x = ((lng - RWANDA_BOUNDS.west) / (RWANDA_BOUNDS.east - RWANDA_BOUNDS.west)) * width;
  const y = ((RWANDA_BOUNDS.north - lat) / (RWANDA_BOUNDS.north - RWANDA_BOUNDS.south)) * height;
  
  return { x, y };
}

export default function BusTracker({ routes }: { routes: Route[] }) {
  const [buses, setBuses] = useState<Bus[]>([]);
  const [selectedBusId, setSelectedBusId] = useState<string | null>(null);

  useEffect(() => {
    const q = query(collection(db, 'buses'), where('status', '==', 'active'));
    return onSnapshot(q, (snapshot) => {
      const busData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Bus));
      setBuses(busData);
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, 'buses-active');
    });
  }, []);

  const selectedBus = buses.find(b => b.id === selectedBusId);
  const selectedRoute = routes.find(r => r.id === selectedBus?.routeId);

  return (
    <div className="relative w-full h-[650px] rounded-[2.5rem] overflow-hidden shadow-2xl shadow-slate-200 border border-slate-200 bg-slate-100 font-sans">
      {/* Stylized SVG Map of Rwanda */}
      <div className="absolute inset-0 bg-[#f1f5f9]">
        <svg viewBox="0 0 800 654" className="w-full h-full">
          {/* Subtle Road Grids */}
          <path d="M0 150 L800 170 M0 450 L800 470 M350 0 L370 654 M550 0 L530 654" stroke="#e2e8f0" strokeWidth="40" fill="none" />
          <path d="M0 150 L800 170 M0 450 L800 470 M350 0 L370 654 M550 0 L530 654" stroke="#cbd5e1" strokeWidth="1" strokeDasharray="10,10" fill="none" />
          
          {/* Major Junctions */}
          <circle cx="360" cy="280" r="120" fill="emerald" fillOpacity="0.03" />
          <circle cx="360" cy="280" r="4" fill="#94a3b8" />
          <text x="375" y="285" fill="#64748b" className="text-[10px] font-bold uppercase tracking-widest">Kigali Center</text>

          {/* Render Buses */}
          <AnimatePresence>
            {buses.map(bus => {
              const { x, y } = project(bus.currentLat, bus.currentLng);
              const isSelected = selectedBusId === bus.id;
              
              return (
                <motion.g 
                  key={bus.id}
                  initial={{ scale: 0, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1, x, y }}
                  transition={{ type: 'spring', damping: 15 }}
                  className="cursor-pointer"
                  onClick={() => setSelectedBusId(isSelected ? null : bus.id)}
                >
                  {isSelected && (
                    <circle r="24" fill="#10b981" fillOpacity="0.1" className="animate-pulse" />
                  )}
                  <circle r="12" fill={isSelected ? "#10b981" : "#ffffff"} stroke={isSelected ? "#ffffff" : "#10b981"} strokeWidth="2.5" />
                  <foreignObject x="-8" y="-8" width="16" height="16">
                    <div className={isSelected ? "text-white" : "text-emerald-600"}>
                      <BusFront size={16} />
                    </div>
                  </foreignObject>
                  <text y="24" textAnchor="middle" className="text-[9px] font-black fill-slate-800 uppercase tracking-tighter">
                    {bus.licensePlate}
                  </text>
                </motion.g>
              );
            })}
          </AnimatePresence>
        </svg>
      </div>

      {/* Map Identity Overlay */}
      <div className="absolute top-8 left-8 z-10 bg-white/90 backdrop-blur-md px-5 py-4 rounded-3xl shadow-xl shadow-slate-900/10 border border-white/50">
        <div className="flex items-center gap-3 text-emerald-700 font-black tracking-tight mb-1 text-lg">
          <div className="w-2.5 h-2.5 bg-emerald-500 rounded-full animate-pulse ring-4 ring-emerald-500/20" />
          Live Fleet Grid
        </div>
        <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest leading-none">
          Simulated National Network: {buses.length} active units
        </p>
      </div>

      {/* Floating Info Panel */}
      <AnimatePresence>
        {selectedBus && (
          <motion.div 
            initial={{ opacity: 0, scale: 0.9, y: 10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 10 }}
            className="absolute top-8 right-8 w-72 bg-white rounded-[2rem] shadow-2xl border border-slate-100 p-6 z-20"
          >
            <div className="flex justify-between items-start mb-4">
              <div className="w-12 h-12 bg-emerald-100 text-emerald-600 rounded-2xl flex items-center justify-center">
                <BusFront size={24} />
              </div>
              <button 
                onClick={() => setSelectedBusId(null)}
                className="text-slate-300 hover:text-slate-500 transition-colors"
              >
                ×
              </button>
            </div>
            <h3 className="text-xl font-black text-slate-800 tracking-tight mb-1">{selectedRoute?.name || 'Local Transit'}</h3>
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-[0.2em] mb-6">Unit: {selectedBus.licensePlate}</p>
            
            <div className="space-y-4">
              <div className="flex justify-between items-center text-sm">
                <span className="text-slate-400 font-medium">Position</span>
                <span className="font-mono text-slate-800">{selectedBus.currentLat.toFixed(4)}, {selectedBus.currentLng.toFixed(4)}</span>
              </div>
              <div className="flex justify-between items-center text-sm">
                <span className="text-slate-400 font-medium">Last Ping</span>
                <span className="text-emerald-600 font-bold">{new Date(selectedBus.lastUpdated?.seconds * 1000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
              </div>
              <div className="h-1.5 w-full bg-slate-50 rounded-full overflow-hidden mt-4">
                <div className="h-full bg-emerald-500 w-2/3" />
              </div>
              <p className="text-[10px] text-center text-slate-400 font-bold uppercase tracking-widest italic">On Schedule</p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Footer Status Bar */}
      <div className="absolute bottom-10 left-10 right-10 flex gap-4 hidden md:flex pointer-events-none">
        <div className="bg-slate-900 shadow-2xl rounded-3xl p-6 flex items-center gap-8 flex-1 border border-white/10 max-w-3xl">
          <div className="flex items-center gap-4 border-r border-slate-800 pr-8">
             <div className="w-10 h-10 bg-emerald-500 rounded-xl flex items-center justify-center text-white">
                <Navigation size={20} />
             </div>
             <div>
               <p className="text-[9px] uppercase font-bold text-slate-400 tracking-widest">Grid Load</p>
               <p className="text-white font-black tracking-tight">Optimal</p>
             </div>
          </div>
          
          <div className="flex-1 space-y-2">
            <div className="flex justify-between text-[9px] uppercase font-bold text-slate-500 tracking-widest">
              <span>National Node Coverage</span>
              <span>88% Efficiency</span>
            </div>
            <div className="h-1 bg-slate-800 rounded-full overflow-hidden">
               <motion.div 
                 initial={{ width: 0 }} 
                 animate={{ width: '88%' }} 
                 className="h-full bg-emerald-500" 
               />
            </div>
          </div>

          <div className="text-right pl-8 border-l border-slate-800">
             <p className="text-[9px] uppercase font-bold text-slate-400 tracking-widest">Uptime</p>
             <p className="text-emerald-500 font-black tracking-tight">99.9%</p>
          </div>
        </div>
      </div>
    </div>
  );
}

