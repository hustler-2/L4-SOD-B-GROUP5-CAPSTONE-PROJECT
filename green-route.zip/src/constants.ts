export const KIGALI_COORDS = { lat: -1.9441, lng: 30.0619 };

export const RWANDA_BOUNDS = {
  north: -1.047,
  south: -2.84,
  west: 28.84,
  east: 30.89,
};

export const ROUTES_SAMPLE_DATA = [
  { id: 'r1', name: 'Kigali - Musanze', origin: 'Kigali', destination: 'Musanze', price: 2500 },
  { id: 'r2', name: 'Kigali - Gisenyi', origin: 'Kigali', destination: 'Gisenyi', price: 3500 },
  { id: 'r3', name: 'Kigali - Butare', origin: 'Kigali', destination: 'Butare', price: 3000 },
  { id: 'r4', name: 'Kigali - Nyagatare', origin: 'Kigali', destination: 'Nyagatare', price: 4000 },
];
