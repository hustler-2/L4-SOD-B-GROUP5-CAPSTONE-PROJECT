/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from 'react';
import { collection, onSnapshot, getDocs, doc, setDoc, serverTimestamp } from 'firebase/firestore';
import { db, auth } from './firebase';
import { handleFirestoreError, OperationType } from './firestoreUtils';
import { Route, Bus } from './types';
import { ROUTES_SAMPLE_DATA, KIGALI_COORDS } from './constants';
import { AuthProvider, useAuth } from './AuthProvider';
import { GoogleAuthProvider, signInWithPopup, signOut } from 'firebase/auth';
import BusTracker from './components/BusTracker';
import BookingForm from './components/BookingForm';
import { Button } from './components/Button';
import { Toaster } from 'react-hot-toast';
import { 
  BusFront, 
  Map as MapIcon, 
  Ticket, 
  User as UserIcon, 
  LogOut, 
  Loader2,
  ChevronRight,
  TrendingUp,
  MapPin,
  Clock
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

function Header() {
  const { user, loading } = useAuth();

  const handleLogin = async () => {
    const provider = new GoogleAuthProvider();
    try {
      await signInWithPopup(auth, provider);
    } catch (error) {
      console.error('Login error:', error);
    }
  };

  const handleLogout = () => signOut(auth);

  return (
    <header className="sticky top-0 z-50 bg-white border-b border-slate-200 px-8 py-4">
      <div className="max-w-7xl mx-auto flex justify-between items-center">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-emerald-600 rounded-lg flex items-center justify-center text-white shadow-lg shadow-emerald-100">
            <BusFront size={20} />
          </div>
          <span className="text-xl font-bold tracking-tight text-slate-800">Green Route</span>
        </div>

        <nav className="hidden md:flex space-x-8 text-sm font-medium text-slate-600">
          <a href="#" className="text-emerald-600 border-b-2 border-emerald-600 pb-1">Book Seat</a>
          <a href="#" className="hover:text-emerald-600 transition-colors">Live Tracking</a>
          <a href="#" className="hover:text-emerald-600 transition-colors">My Tickets</a>
          <a href="#" className="hover:text-emerald-600 transition-colors">Routes</a>
        </nav>

        <div className="flex items-center gap-4">
          {loading ? (
            <Loader2 className="animate-spin text-slate-400" />
          ) : user ? (
            <div className="flex items-center gap-3 bg-slate-50 p-1 pr-4 rounded-full border border-slate-200">
              <img src={user.photoURL || ''} alt="" className="w-8 h-8 rounded-full border border-white shadow-sm" />
              <span className="text-sm font-semibold text-slate-700 hidden sm:inline">{user.displayName?.split(' ')[0]}</span>
              <button 
                onClick={handleLogout}
                className="p-1 text-slate-400 hover:text-red-600 transition-colors"
                title="Logout"
              >
                <LogOut size={16} />
              </button>
            </div>
          ) : (
            <div className="flex items-center space-x-2">
              <button onClick={handleLogin} className="px-4 py-2 text-sm font-semibold text-slate-700 hover:text-emerald-600 transition-colors">Sign In</button>
              <Button onClick={handleLogin} variant="primary" size="sm" className="rounded-lg">Register</Button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}

function DemoController({ routes, buses }: { routes: Route[]; buses: Bus[] }) {
  const [loading, setLoading] = useState(false);
  const [isSimulating, setIsSimulating] = useState(false);

  const seedData = async () => {
    setLoading(true);
    try {
      // Seed Routes
      for (const r of ROUTES_SAMPLE_DATA) {
        await setDoc(doc(db, 'routes', r.id), r);
      }
      // Seed a few Buses near Kigali
      const samples = [
        { id: 'b1', routeId: 'r1', licensePlate: 'RAA 123 B', capacity: 30, status: 'active', currentLat: KIGALI_COORDS.lat + 0.01, currentLng: KIGALI_COORDS.lng + 0.01 },
        { id: 'b2', routeId: 'r2', licensePlate: 'RAD 456 C', capacity: 30, status: 'active', currentLat: KIGALI_COORDS.lat - 0.02, currentLng: KIGALI_COORDS.lng + 0.015 },
        { id: 'b3', routeId: 'r3', licensePlate: 'RAB 789 D', capacity: 30, status: 'active', currentLat: KIGALI_COORDS.lat + 0.005, currentLng: KIGALI_COORDS.lng - 0.01 },
      ];
      for (const b of samples) {
        await setDoc(doc(db, 'buses', b.id), { ...b, lastUpdated: serverTimestamp() });
      }
      window.location.reload();
    } catch (e) {
      handleFirestoreError(e, OperationType.WRITE, 'seed-data');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isSimulating && buses.length > 0) {
      interval = setInterval(async () => {
        // Pick a random bus to move
        const randomBus = buses[Math.floor(Math.random() * buses.length)];
        const deltaLat = (Math.random() - 0.5) * 0.002;
        const deltaLng = (Math.random() - 0.5) * 0.002;

        try {
          await setDoc(doc(db, 'buses', randomBus.id), {
            ...randomBus,
            currentLat: randomBus.currentLat + deltaLat,
            currentLng: randomBus.currentLng + deltaLng,
            lastUpdated: serverTimestamp()
          });
        } catch (e) {
          console.error("Simulation update failed:", e);
        }
      }, 3000);
    }
    return () => clearInterval(interval);
  }, [isSimulating, buses]);

  const hasData = routes.length > 0 && buses.length > 0;

  return (
    <div className={cn(
      "p-6 rounded-3xl mb-8 flex flex-col md:flex-row items-center justify-between gap-6 transition-all border",
      isSimulating ? "bg-emerald-900 border-emerald-700 text-white shadow-2xl shadow-emerald-500/20" : "bg-white border-slate-200 shadow-sm"
    )}>
      <div className="flex items-center gap-4">
        <div className={cn(
          "w-12 h-12 rounded-2xl flex items-center justify-center transition-colors",
          isSimulating ? "bg-emerald-500 text-white" : "bg-slate-100 text-slate-400"
        )}>
          {isSimulating ? <MapPin className="animate-bounce" /> : <BusFront />}
        </div>
        <div>
          <h3 className={cn("font-bold text-lg", isSimulating ? "text-white" : "text-slate-900")}>
            {isSimulating ? "Live Simulation Active" : "Demo Control Center"}
          </h3>
          <p className={cn("text-xs font-medium uppercase tracking-widest opacity-70")}>
            {hasData ? "Database ready for testing" : "Setup required to begin"}
          </p>
        </div>
      </div>

      <div className="flex gap-3 w-full md:w-auto">
        {!hasData ? (
          <Button onClick={seedData} disabled={loading} variant="primary" className="flex-1 md:flex-none">
            {loading ? <Loader2 className="animate-spin" /> : 'Initial Database Setup'}
          </Button>
        ) : (
          <Button 
            onClick={() => setIsSimulating(!isSimulating)} 
            variant={isSimulating ? "outline" : "primary"}
            className={cn(
              "flex-1 md:flex-none gap-2",
              isSimulating ? "bg-transparent border-white/20 text-white hover:bg-white/10" : "bg-emerald-600 shadow-emerald-200"
            )}
          >
            {isSimulating ? (
              <><LogOut size={18} /> Stop Simulation</>
            ) : (
              <><TrendingUp size={18} /> Start Real-time Demo</>
            )}
          </Button>
        )}
      </div>
    </div>
  );
}

function MainContent() {
  const [routes, setRoutes] = useState<Route[]>([]);
  const [buses, setBuses] = useState<Bus[]>([]);
  const [activeTab, setActiveTab] = useState<'booking' | 'tracking'>('booking');

  useEffect(() => {
    const unsubRoutes = onSnapshot(collection(db, 'routes'), (snapshot) => {
      setRoutes(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Route)));
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, 'routes');
    });
    const unsubBuses = onSnapshot(collection(db, 'buses'), (snapshot) => {
      setBuses(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Bus)));
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, 'buses');
    });
    return () => { unsubRoutes(); unsubBuses(); };
  }, []);

  return (
    <main className="max-w-7xl mx-auto px-8 py-10">
      <DemoController routes={routes} buses={buses} />

      <section className="mb-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <motion.div 
            initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
            className="md:col-span-2 relative h-72 rounded-[2rem] overflow-hidden bg-emerald-600 p-12 text-white flex flex-col justify-center shadow-2xl shadow-emerald-200"
          >
            <div className="absolute top-0 right-0 p-8 opacity-10 blur-sm">
              <Ticket size={240} className="rotate-12" />
            </div>
            <div className="relative z-10">
              <span className="px-3 py-1 bg-white/20 backdrop-blur-sm rounded-full text-[10px] font-bold tracking-widest uppercase mb-4 inline-block">Direct Booking System</span>
              <h2 className="text-4xl font-extrabold mb-3 leading-tight tracking-tight">Travel Smarter <br/>Across Rwanda</h2>
              <p className="text-emerald-50 max-w-sm mb-8 text-lg font-medium opacity-90">Real-time bus tracking and effortless seat booking. Skip the queue, book online.</p>
              <Button onClick={() => setActiveTab('booking')} className="bg-white text-emerald-700 hover:bg-emerald-50 px-8 py-3.5 rounded-xl font-bold shadow-xl shadow-emerald-900/20 active:scale-95">
                Start Booking
              </Button>
            </div>
          </motion.div>

          <div className="grid grid-cols-1 gap-6">
            <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm flex flex-col justify-between">
              <div className="w-12 h-12 bg-emerald-50 text-emerald-600 rounded-2xl flex items-center justify-center mb-4 border border-emerald-100">
                <TrendingUp size={24} />
              </div>
              <div>
                <p className="text-3xl font-black text-slate-800 tracking-tighter">{routes.length}</p>
                <p className="text-sm text-slate-500 font-semibold tracking-wide uppercase text-[10px]">Inter-city Routes</p>
              </div>
            </div>
            <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm flex flex-col justify-between">
              <div className="w-12 h-12 bg-slate-50 text-slate-600 rounded-2xl flex items-center justify-center mb-4 border border-slate-200">
                <MapPin size={24} />
              </div>
              <div>
                <p className="text-3xl font-black text-slate-800 tracking-tighter">{buses.filter(b => b.status === 'active').length}</p>
                <p className="text-sm text-slate-500 font-semibold tracking-wide uppercase text-[10px]">Active Units Live</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <div className="flex gap-2 p-1.5 bg-slate-100/50 rounded-xl w-fit mb-10 sticky top-24 z-40 shadow-sm backdrop-blur-sm border border-slate-200/50 text-sm">
        <button
          onClick={() => setActiveTab('booking')}
          className={cn(
            "flex items-center gap-2 px-6 py-2.5 rounded-lg font-bold transition-all",
            activeTab === 'booking' ? "bg-white text-emerald-600 shadow-sm border border-slate-200/50" : "text-slate-500 hover:text-slate-700 hover:bg-slate-50"
          )}
        >
          <Ticket size={18} /> Book Seat
        </button>
        <button
          onClick={() => setActiveTab('tracking')}
          className={cn(
            "flex items-center gap-2 px-6 py-2.5 rounded-lg font-bold transition-all",
            activeTab === 'tracking' ? "bg-white text-emerald-600 shadow-sm border border-slate-200/50" : "text-slate-500 hover:text-slate-700 hover:bg-slate-50"
          )}
        >
          <MapIcon size={18} /> Live Tracking
        </button>
      </div>

      <AnimatePresence mode="wait">
        {activeTab === 'booking' ? (
          <motion.div
            key="booking"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
          >
            <BookingForm routes={routes} buses={buses.filter(b => b.status === 'active')} />
          </motion.div>
        ) : (
          <motion.div
            key="tracking"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
          >
            <div className="mb-8">
              <h2 className="text-2xl font-bold text-slate-800 tracking-tight mb-2">Live Fleet Intelligence</h2>
              <p className="text-slate-500 text-sm">Monitoring real-time GPS coordinates of active units across the national grid.</p>
            </div>
            <BusTracker routes={routes} />
          </motion.div>
        )}
      </AnimatePresence>

      <footer className="mt-24 pt-12 pb-8 border-t border-slate-200 flex flex-col md:flex-row justify-between items-center gap-8 text-slate-500 text-xs font-medium">
        <div className="flex items-center gap-6">
          <span className="text-slate-900 font-bold tracking-tight">Green Route Rwanda</span>
          <a href="#" className="hover:text-emerald-600 transition-colors">Terms of Service</a>
          <a href="#" className="hover:text-emerald-600 transition-colors">Privacy Policy</a>
        </div>
        <div className="flex items-center gap-6">
          <span className="flex items-center gap-1.5">
            <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></span>
            <span>Server Status: <span className="text-emerald-600">Secure</span></span>
          </span>
          <span className="text-slate-400">Support: <span className="text-slate-800 font-semibold">+250 780 000 000</span></span>
        </div>
        <p>© 2026 Green Route Inc.</p>
      </footer>
    </main>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <div className="min-h-screen bg-slate-50 text-slate-900 font-sans antialiased selection:bg-emerald-100 selection:text-emerald-900">
        <Toaster position="top-center" />
        <Header />
        <MainContent />
      </div>
    </AuthProvider>
  );
}

function cn(...classes: string[]) {
  return classes.filter(Boolean).join(' ');
}

