import { useState } from 'react';
import { Route, Bus, Booking } from '../types';
import { addDoc, collection, serverTimestamp } from 'firebase/firestore';
import { db, auth } from '../firebase';
import { handleFirestoreError, OperationType } from '../firestoreUtils';
import { useAuth } from '../AuthProvider';
import { Button } from './Button';
import { Check, Loader2, User, Armchair, MoveRight, BusFront, Info } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import toast from 'react-hot-toast';

export default function BookingForm({ routes, buses }: { routes: Route[]; buses: Bus[] }) {
  const { user } = useAuth();
  const [selectedRoute, setSelectedRoute] = useState<Route | null>(null);
  const [selectedBus, setSelectedBus] = useState<Bus | null>(null);
  const [selectedSeats, setSelectedSeats] = useState<number[]>([]);
  const [isBooking, setIsBooking] = useState(false);

  const handleRouteSelect = (route: Route) => {
    setSelectedRoute(route);
    setSelectedBus(null);
    setSelectedSeats([]);
  };

  const handleBusSelect = (bus: Bus) => {
    setSelectedBus(bus);
    setSelectedSeats([]);
  };

  const toggleSeat = (seat: number) => {
    setSelectedSeats(prev => 
      prev.includes(seat) ? prev.filter(s => s !== seat) : [...prev, seat]
    );
  };

  const handleBook = async () => {
    if (!user || !selectedBus || selectedSeats.length === 0) return;

    setIsBooking(true);
    try {
      await addDoc(collection(db, 'bookings'), {
        busId: selectedBus.id,
        userId: user.uid,
        seats: selectedSeats,
        totalPrice: selectedSeats.length * (selectedRoute?.price || 0),
        status: 'confirmed',
        timestamp: serverTimestamp(),
      });
      toast.success('Seats booked successfully!');
      setSelectedSeats([]);
      setSelectedBus(null);
      setSelectedRoute(null);
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, 'bookings');
      toast.error('Booking failed. Please try again.');
    } finally {
      setIsBooking(false);
    }
  };

  const availableBuses = buses.filter(b => b.routeId === selectedRoute?.id);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
      {/* Selection Area */}
      <div className="lg:col-span-4 space-y-8">
        <section>
          <h2 className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-4 flex items-center gap-2">
            <div className="w-6 h-6 bg-emerald-100 text-emerald-600 rounded-md flex items-center justify-center text-[10px]">01</div>
            Select Route
          </h2>
          <div className="grid grid-cols-1 gap-4">
            {routes.map(route => (
              <button
                key={route.id}
                onClick={() => handleRouteSelect(route)}
                className={cn(
                  "p-5 rounded-xl border transition-all text-left group",
                  selectedRoute?.id === route.id ? "border-emerald-600 bg-emerald-50/50 ring-1 ring-emerald-600" : "border-slate-100 bg-white hover:border-emerald-200"
                )}
              >
                <div className="flex justify-between items-center">
                  <div>
                    <p className="font-bold text-slate-800 group-hover:text-emerald-700 transition-colors">{route.name}</p>
                    <p className="text-[11px] text-slate-400 font-semibold uppercase tracking-tight mt-0.5">{route.origin} → {route.destination}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-slate-900 group-hover:text-emerald-600">{route.price.toLocaleString()} RWF</p>
                    <p className="text-[10px] text-slate-400">Fixed Rate</p>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </section>

        {selectedRoute && (
          <motion.section initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="pt-4 border-t border-slate-100">
            <h2 className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-4 flex items-center gap-2">
              <div className="w-6 h-6 bg-slate-200 text-slate-600 rounded-md flex items-center justify-center text-[10px]">02</div>
              Available Units
            </h2>
            <div className="grid grid-cols-1 gap-3">
              {availableBuses.length > 0 ? (
                availableBuses.map(bus => (
                  <button
                    key={bus.id}
                    onClick={() => handleBusSelect(bus)}
                    className={cn(
                      "p-4 rounded-xl border transition-all text-left",
                      selectedBus?.id === bus.id ? "border-emerald-600 bg-emerald-50/30" : "border-slate-200 bg-white hover:border-emerald-200"
                    )}
                  >
                    <div className="flex justify-between items-center">
                      <div className="flex items-center gap-4">
                        <div className="w-10 h-10 bg-slate-50 rounded-lg border border-slate-100 flex items-center justify-center">
                          <BusFront className="text-slate-400" size={18} />
                        </div>
                        <div>
                          <p className="font-bold text-slate-800">{bus.licensePlate}</p>
                          <span className="text-[11px] font-bold px-1.5 py-0.5 bg-emerald-600 text-white rounded-md uppercase tracking-wide">On Schedule</span>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-xs font-bold text-emerald-600">{bus.capacity} Capacity</p>
                      </div>
                    </div>
                  </button>
                ))
              ) : (
                <div className="text-slate-400 text-sm italic p-6 bg-slate-50/50 rounded-xl border border-dashed border-slate-200 text-center">
                  No active units detected for this path.
                </div>
              )}
            </div>
          </motion.section>
        )}
      </div>

      {/* Seat Selection and Checkout */}
      <div className="lg:col-span-8 bg-white p-8 rounded-3xl shadow-sm border border-slate-200 h-fit sticky top-28">
        <div className="flex items-center justify-between mb-10">
          <h2 className="text-xl font-bold text-slate-800 tracking-tight">Booking Overview</h2>
          <div className="flex gap-2">
            <div className="flex items-center gap-1.5">
              <div className="w-3 h-3 bg-emerald-600 rounded-sm"></div>
              <span className="text-[10px] font-bold text-slate-400 uppercase">Selected</span>
            </div>
            <div className="flex items-center gap-1.5 ml-4">
              <div className="w-3 h-3 bg-slate-100 rounded-sm border border-slate-200"></div>
              <span className="text-[10px] font-bold text-slate-400 uppercase">Available</span>
            </div>
          </div>
        </div>
        
        {!selectedBus ? (
          <div className="flex flex-col items-center justify-center py-20 text-slate-300">
            <div className="bg-slate-50 w-20 h-20 rounded-full flex items-center justify-center mb-6">
              <Armchair size={40} className="opacity-30" />
            </div>
            <p className="font-medium text-slate-400">Perform path selection to configure reservation</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            <div className="space-y-8">
              <div>
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-6">Configuration: Seat Grid</p>
                <div className="grid grid-cols-4 gap-4 max-w-[280px]">
                  {Array.from({ length: 16 }).map((_, i) => {
                    const seatNum = i + 1;
                    const isSelected = selectedSeats.includes(seatNum);
                    return (
                      <button
                        key={seatNum}
                        onClick={() => toggleSeat(seatNum)}
                        className={cn(
                          "aspect-square rounded-xl flex items-center justify-center text-sm font-bold transition-all border",
                          isSelected 
                            ? "bg-emerald-600 text-white border-emerald-600 shadow-lg shadow-emerald-200 scale-105 z-10" 
                            : "bg-slate-50 text-slate-400 border-slate-100 hover:border-emerald-200 hover:bg-white"
                        )}
                      >
                        {seatNum}
                      </button>
                    );
                  })}
                </div>
              </div>
              
              <div className="bg-emerald-50 p-4 rounded-xl border border-emerald-100 flex gap-4">
                <Info size={20} className="text-emerald-600 shrink-0" />
                <p className="text-[11px] text-emerald-800 leading-relaxed font-medium">
                  Select your preferred seating. Real-time availability is synced with the dispatch center. Support is available 24/7.
                </p>
              </div>
            </div>

            <div className="flex flex-col justify-between pt-2">
              <div className="space-y-6">
                <div className="pb-6 border-b border-slate-100">
                  <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-4">Journey Data</p>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center text-sm">
                      <span className="text-slate-500">Route</span>
                      <span className="font-bold text-slate-800">{selectedRoute?.name}</span>
                    </div>
                    <div className="flex justify-between items-center text-sm">
                      <span className="text-slate-500">Unit ID</span>
                      <span className="font-bold text-slate-800 font-mono tracking-tighter">{selectedBus.licensePlate}</span>
                    </div>
                    <div className="flex justify-between items-center text-sm">
                      <span className="text-slate-500">Seats</span>
                      <span className="font-bold text-emerald-600">{selectedSeats.length > 0 ? selectedSeats.join(', ') : 'None'}</span>
                    </div>
                  </div>
                </div>

                <div className="pt-2">
                  <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2">Total Payable</p>
                  <div className="flex items-baseline gap-2">
                    <p className="text-4xl font-black text-slate-900 tracking-tighter">
                      {(selectedSeats.length * (selectedRoute?.price || 0)).toLocaleString()}
                    </p>
                    <p className="text-lg font-bold text-slate-400 uppercase">RWF</p>
                  </div>
                  <p className="text-[11px] text-slate-400 font-medium mt-1">Inclusive of all station taxes and service fees.</p>
                </div>
              </div>

              <div className="mt-12 space-y-4">
                {!user ? (
                  <Button 
                    variant="outline"
                    className="w-full h-14 bg-slate-50 border-slate-200 text-slate-500 pointer-events-none italic"
                  >
                    Authentication Required
                  </Button>
                ) : (
                  <Button 
                    onClick={handleBook} 
                    disabled={selectedSeats.length === 0 || isBooking}
                    className="w-full h-14 text-sm uppercase tracking-widest font-black gap-3 rounded-xl"
                  >
                    {isBooking ? <Loader2 className="animate-spin" /> : <><Check size={18} /> Confirm Order</>}
                  </Button>
                )}
                <p className="text-center text-[10px] font-bold text-slate-300 uppercase tracking-widest">
                  Secure Checkout System
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function cn(...classes: string[]) {
  return classes.filter(Boolean).join(' ');
}
